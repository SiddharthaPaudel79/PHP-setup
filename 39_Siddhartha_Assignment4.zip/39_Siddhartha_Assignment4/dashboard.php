<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<h2>Dashboard</h2>
<?php
if ($_SESSION['role'] == 'admin') {
    echo "<a href='admin_dashboard.php'>Admin Dashboard</a><br>";
} else {
    echo "<a href='add_complaint.php'>Submit Complaint</a><br>";
    echo "<a href='my_complaints.php'>My Complaints</a><br>";
}
?>
<a href="logout.php">Logout</a>
