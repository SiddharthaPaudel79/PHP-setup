<?php
$connection = mysqli_connect("localhost", "root", "", "complaint_system");
if (!$connection) {
    die("Database connection failed");
}
?>
